<?php

    ob_start();



    $servername = "localhost";
    $username = "root";
    $password = "Frederick01nielsen";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=pristjek", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "";
    }
    catch(PDOException $e) {
      echo "Kunne ikke forbinde til database: " . $e->getMessage();
    }





?>
