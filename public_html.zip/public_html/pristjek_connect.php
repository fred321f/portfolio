<?php

    ob_start();



    $servername = "mysql21.unoeuro.com";
    $username = "bedstepris_nu";
    $password = "ptzx4m9aBrDA6new2R3E";

    try {
        $conn = new PDO("mysql:host=$servername;port=3306;dbname=bedstepris_nu_db", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "";
    }
    catch(PDOException $e) {
      echo "Kunne ikke forbinde til database: " . $e->getMessage();
    }




?>
