<nav class="navbar  navbar-expand-lg navbar-light shadow-none bg-mogul p-2 py-4 rounded">

  <div class="container-md">


      <a class="navbar-brand" href="../index.php" ><b>Bedstepris.nu</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>


    <div class="d-flex flex-row-reverse bd-highlight">

      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">

        <a class="nav-link" href="about.php" tabindex="-1" aria-disabled="true"><i class="fa-solid fa-circle-info"></i> Om siden</a>
        </div>
      </div>
    </div>
  </div>
</nav>
